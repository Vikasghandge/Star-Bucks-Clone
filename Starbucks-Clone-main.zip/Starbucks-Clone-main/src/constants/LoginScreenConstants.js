export const LOGIN_SCREEN_HEADER="Sign In or create an account 🌟"
export const LOGIN_SCREEN_FORGOT_LINKS={
    email:"Forgot your username?",
    passowrd:"Forgot your password?"
}
export const LOGIN_SCREEN_STARBUCKS_REWARDS={
    heading:"JOIN STARBUCKS® REWARDS",
    join_now:"Join Now",
    heading_create_account:"Create an account and bring on the Rewards!",
    paragraph:" Join Starbucks® Rewards to earn free food and drinks, get free refills, pay and order with your phone, and more."
}