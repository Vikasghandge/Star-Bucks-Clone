export const FEATURED_GIFT_SCREEN_URLS = [
    "https://globalassets.starbucks.com/assets/5b29d835ced3407ab59aa4be220ee9ec.jpg",
    "https://globalassets.starbucks.com/assets/3f0137ff0c8b476d8400a8de9880cc7f.jpg",
    "https://globalassets.starbucks.com/assets/45f1c4ed8dac426ea31d09bc4296771c.jpg",
    "https://globalassets.starbucks.com/assets/1c47ac4f6e914144b8d6a2e3489f316e.jpg",
    "https://globalassets.starbucks.com/assets/bb5003220b16472c8efd7c1968edb836.jpg",
    "https://globalassets.starbucks.com/assets/71a33636e9584010986cf95ae7749016.jpg",
    "https://globalassets.starbucks.com/assets/d2346fc58ecb4ce39534452c5c527c11.jpg",
    "https://globalassets.starbucks.com/assets/f0a22aa4b43846bbb4795f1518650968.jpg"
]

export const THANKYOU_GIFT_SCREEN_URLS = [
    "https://globalassets.starbucks.com/assets/7a624543bdda464698be079655ae8b6b.jpg",
    "https://globalassets.starbucks.com/assets/a1e98bec4d304103a5b49ec968b60782.jpg",
    "https://globalassets.starbucks.com/assets/f8167a08eaab4d2197729d2967caedad.jpg",
    "https://globalassets.starbucks.com/assets/3196fef83fbe49a58ea7c19bb685cc5c.jpg",
    "https://globalassets.starbucks.com/assets/a8fa33a190374fe69bf1de429a03053a.jpg"
]

export const BIRTHDAY_GIFT_SCREEN_URLS = [
    "https://globalassets.starbucks.com/assets/3180f6ca900446299071bd801308e08d.jpg",
    "https://globalassets.starbucks.com/assets/fe911f70905741f6a71a6072a203b860.jpg",
    "https://globalassets.starbucks.com/assets/dacf804b33a44af8bb1e3793e4085f08.jpg",
    "https://globalassets.starbucks.com/assets/33f5dea8c80a4745950ba0179bbbe144.jpg",
    "https://globalassets.starbucks.com/assets/45f1c4ed8dac426ea31d09bc4296771c.jpg"
]

export const LOVE_GIFT_SCREEN_URLS = [
    "https://globalassets.starbucks.com/assets/f0a22aa4b43846bbb4795f1518650968.jpg",
    "https://globalassets.starbucks.com/assets/9aec178d5b3d40ad86d19286efdf9634.jpg",
    "https://globalassets.starbucks.com/assets/432be6dc21334736857db5582c5449be.jpg",
    "https://globalassets.starbucks.com/assets/bf2740bad4904901a507b748d2f02db9.jpg",
]

export const SUMMER_GIFT_SCREEN_URLS = [
    "https://globalassets.starbucks.com/assets/f733d531e96f447d8e12b4054aa3dee6.jpg",
    "https://globalassets.starbucks.com/assets/4e46f8b8cd994e84b59868c77fe85570.jpg"
]

export const PARENTS_GIFT_SCREEN_URLS=[
    "https://globalassets.starbucks.com/assets/87fb2c3d2c874799aacc8f45a033fdfa.jpg",
    "https://globalassets.starbucks.com/assets/3f0137ff0c8b476d8400a8de9880cc7f.jpg"
]
