export const HOME_PAGE="/"

export const SIGN_IN="/account/signin"

export const SIGN_UP="/account/signup"

export const MENU_PAGE="/menu"

export const REWARDS_PAGE="/rewards"

export const REWARDS_PAGE_MOBILE="/rewards/mobile-apps"

export const GIFT_CARDS_PAGE="/gift-cards"

export const MENU_FEATURED_PAGE="/menu/featured"

export const FIND_STORE="/store-locator"

export const MENU_TODAYSPL_PAGE="/menu/today's-spl"
