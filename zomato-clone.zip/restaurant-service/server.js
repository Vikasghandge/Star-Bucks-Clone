const express = require('express');
const mysql = require('mysql2');
const app = express();
app.use(express.json());

const db = mysql.createConnection({
  host: 'mysql-service',
  user: 'root',
  password: 'password',
  database: 'zomato'
});

app.get('/restaurants', (req, res) => {
  db.query('SELECT * FROM restaurants', (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

app.listen(3001, () => {
  console.log('Restaurant service on port 3001');
});