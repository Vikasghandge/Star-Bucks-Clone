import React from 'react'

const Pay = () => {
  return (
    <div className='md:h-[400px] md:text-2xl flex items-center justify-center'>Pay</div>
  )
}

export default Pay