import React from 'react'

const Store = () => {
  return (
    <div className='md:h-[400px] md:text-2xl flex items-center justify-center'>Store</div>
  )
}

export default Store