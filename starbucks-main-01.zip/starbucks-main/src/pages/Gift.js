import React from 'react'

const Gift = () => {
  return (
    <div className=' md:h-[400px] md:text-2xl flex items-center justify-center'>Gift</div>
  )
}

export default Gift