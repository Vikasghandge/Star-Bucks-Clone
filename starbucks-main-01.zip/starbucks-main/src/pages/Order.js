import React from 'react'

const Order = () => {
  return (
    <div className='md:h-[400px] md:text-2xl flex items-center justify-center'>Order</div>
  )
}

export default Order